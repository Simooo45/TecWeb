package it.unibo.tw.web.beans;

import java.io.Serializable;

public class Drink extends Serializable{
    public String name;
    public float price;
    public bool status = false;

    public Drink(String name, float price){
        this.name = name;
        this.price = price;
        this.status = false;
    }

    public float getPrice(){
        return price;
    }

    public String getName(){
        return name;
    }

    public bool getStatus(){
        return this.status;
    }

    public void consegnato(){
        this.status = true;
    }
}
