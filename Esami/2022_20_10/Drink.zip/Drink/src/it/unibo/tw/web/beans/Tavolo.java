package it.unibo.tw.web.beans;
import java.io.Serializable;
import java.lang.reflect.Array;
import java.util.ArrayList;


public class Tavolo extends Serializable{
    String idTavolo;
    Array<Utente> utenti;

    public Tavolo(String idTavolo){
        this.idTavolo = idTavolo;
        this.utenti = new ArrayList<Utente>();
    }

    public addUtente(Utente u){
        this.utenti.add(u);
    }

    public float totaleTavolo(){
        float totale = 0;
        for (Utente u: this.utenti){
            totale += u.getTotal();
        }
        return totale;
    }

    public ArrayList<Drink> daCons(){
        Array<Drink> daConsegnare = new ArrayList<Drink>();
        for (Utente u: this.utenti){
            for (Drink d: u.getDrinks()){
                if (!d.getStatus()){
                    daConsegnare.add(d);
                }
            }
        }
        return daConsegnare;
    }


}
